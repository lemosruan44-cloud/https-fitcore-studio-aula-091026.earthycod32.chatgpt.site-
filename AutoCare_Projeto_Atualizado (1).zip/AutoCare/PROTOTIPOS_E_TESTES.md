# Prototipagem e validação — AutoCare

## Wireframe de baixa fidelidade (esboço)

```
+-------------------------------------------------------+
| AUTOCARE             Gestão de manutenção veicular    |
+-------------------------------------------------------+
| Total gasto: R$ ...                                   |
| [Cadastrar veículo: modelo | placa | ano] [Salvar]    |
| [Registrar manutenção: veículo | serviço | data]      |
| [Custo | quilometragem] [Salvar]                       |
| Histórico: veículo | serviço | data | custo | excluir  |
| [Novo alerta: veículo | IPVA/revisão | data] [Salvar]  |
| Alertas cadastrados                                   |
+-------------------------------------------------------+
```

## Alta fidelidade
A interface HTML/CSS do sistema é uma referência visual inicial, mas **não substitui** um protótipo interativo no Figma ou similar. Inserir link público do protótipo: [PENDENTE].

## Persona provisória (hipótese)
Proprietário de veículo que deseja centralizar histórico de manutenção e controlar gastos. Revisar com base nas entrevistas.

## Jornada
Cadastrar veículo → registrar serviço → consultar gastos e histórico → cadastrar vencimento → consultar alertas.

## Teste de usabilidade (executar com pessoa real)
1. Cadastrar um veículo fictício.
2. Registrar uma troca de óleo fictícia.
3. Encontrar o custo total.
4. Cadastrar vencimento de IPVA.
5. Anotar erros, tempo e comentários sem inventar resultados.
