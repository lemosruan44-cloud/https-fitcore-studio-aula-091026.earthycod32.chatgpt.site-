# Entrega — Design Profissional

## 20/10 — Pesquisa
Entrevistar 1–2 pessoas reais e apresentar respostas e dores. Use PESQUISA_DE_CAMPO.md.
## 27/10 — Protótipos
Apresentar wireframe e protótipo interativo de alta fidelidade em Figma ou similar.
## 03/11 e 10/11 — Desenvolvimento
Executar localmente, testar com usuários, publicar código e README no GitHub.
## 17/11 — Final
Entregar relatório PDF completo com nomes, papéis, entrevistas, matriz de dores, capturas/link de protótipos, arquitetura e link do repositório. Demonstrar sistema funcionando localmente.

### Publicação
Crie repositório no github.com/new e envie os **arquivos extraídos** da pasta AutoCare, não apenas o ZIP. Não envie banco real com dados pessoais.

### Execução no Windows
`py -m pip install -r requirements.txt`
`py app.py`
Abra http://127.0.0.1:5000
