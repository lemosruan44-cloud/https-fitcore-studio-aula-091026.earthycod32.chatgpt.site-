# AutoCare — MVP de gestão de manutenção veicular

Projeto acadêmico da disciplina Design Profissional, Universidade Positivo.

## Recursos implementados
- Cadastro de veículos
- Registro e exclusão de manutenções
- Histórico com veículo, data, serviço, custo e quilometragem
- Soma dos gastos registrados
- Cadastro e visualização de vencimentos de IPVA, licenciamento e revisão (sem notificação externa)
- Persistência local em SQLite

## Como executar
1. Instale Python 3.10 ou superior.
2. Abra um terminal nesta pasta.
3. Execute `python -m pip install -r requirements.txt`.
4. Execute `python app.py`.
5. Abra `http://127.0.0.1:5000` no navegador.

No Windows, se `python` não funcionar, tente `py`.
O banco `autocare.db` é criado automaticamente.

## Arquitetura
Flask (servidor e rotas) + Jinja2/HTML (interface) + CSS (estilo) + SQLite (banco local).

## Limites do MVP
Não inclui autenticação, notificações automáticas ou integração com dados de veículos. Pesquisa com usuários e testes de usabilidade ainda precisam ser realizados com pessoas reais.
