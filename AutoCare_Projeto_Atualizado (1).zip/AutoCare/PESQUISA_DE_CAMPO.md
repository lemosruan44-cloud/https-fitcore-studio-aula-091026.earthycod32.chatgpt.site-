# Roteiro de pesquisa de campo — AutoCare

Entrevistar 1 a 2 proprietários de veículos. Pedir consentimento para registrar respostas; não é necessário incluir dados pessoais no relatório.

1. Como você acompanha as manutenções do seu veículo hoje?
2. Você já esqueceu alguma revisão ou perdeu comprovantes? O que aconteceu?
3. Como registra os valores gastos com o carro?
4. Que informação seria mais útil ter reunida em um único aplicativo?
5. Você usaria um sistema para registrar serviços e custos? Por quê?

## Entrevistado 1
Perfil: [preencher]
Respostas: [preencher com dados reais]
Dor principal: [preencher]
Oportunidade: [preencher]

## Entrevistado 2 (opcional)
Perfil: [preencher]
Respostas: [preencher com dados reais]
Dor principal: [preencher]
Oportunidade: [preencher]
