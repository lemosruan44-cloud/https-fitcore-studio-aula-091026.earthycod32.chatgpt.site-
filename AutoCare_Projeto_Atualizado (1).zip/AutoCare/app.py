from flask import Flask, render_template, request, redirect
import sqlite3
app=Flask(__name__)
DB='autocare.db'
def query(sql,args=(),fetch=False):
 with sqlite3.connect(DB) as c:
  result=c.execute(sql,args)
  return result.fetchall() if fetch else None
with sqlite3.connect(DB) as c:
 c.execute('CREATE TABLE IF NOT EXISTS veiculos(id INTEGER PRIMARY KEY, modelo TEXT NOT NULL, placa TEXT, ano INTEGER)')
 c.execute('CREATE TABLE IF NOT EXISTS alertas(id INTEGER PRIMARY KEY, veiculo_id INTEGER NOT NULL, tipo TEXT NOT NULL, vencimento TEXT NOT NULL, observacao TEXT, FOREIGN KEY(veiculo_id) REFERENCES veiculos(id))')
 c.execute('CREATE TABLE IF NOT EXISTS manutencoes(id INTEGER PRIMARY KEY, veiculo_id INTEGER, servico TEXT NOT NULL, data TEXT NOT NULL, custo REAL NOT NULL, km INTEGER, FOREIGN KEY(veiculo_id) REFERENCES veiculos(id))')
@app.route('/')
def home():
 veiculos=query('SELECT * FROM veiculos ORDER BY id DESC',fetch=True)
 manutencoes=query('SELECT m.id,v.modelo,m.servico,m.data,m.custo,m.km FROM manutencoes m JOIN veiculos v ON v.id=m.veiculo_id ORDER BY m.data DESC',fetch=True)
 alertas=query('SELECT a.id,v.modelo,a.tipo,a.vencimento,a.observacao FROM alertas a JOIN veiculos v ON v.id=a.veiculo_id ORDER BY a.vencimento',fetch=True)
 total=sum(x[4] for x in manutencoes)
 return render_template('index.html',veiculos=veiculos,manutencoes=manutencoes,total=total,alertas=alertas)
@app.post('/veiculo')
def veiculo():
 query('INSERT INTO veiculos(modelo,placa,ano) VALUES(?,?,?)',(request.form['modelo'],request.form['placa'],request.form['ano'] or None))
 return redirect('/')
@app.post('/manutencao')
def manutencao():
 query('INSERT INTO manutencoes(veiculo_id,servico,data,custo,km) VALUES(?,?,?,?,?)',(request.form['veiculo_id'],request.form['servico'],request.form['data'],float(request.form['custo']),request.form['km'] or None))
 return redirect('/')
@app.post('/alerta')
def alerta():
 query('INSERT INTO alertas(veiculo_id,tipo,vencimento,observacao) VALUES(?,?,?,?)',(request.form['veiculo_id'],request.form['tipo'],request.form['vencimento'],request.form.get('observacao','')))
 return redirect('/')
@app.post('/alerta/excluir/<int:id>')
def excluir_alerta(id):
 query('DELETE FROM alertas WHERE id=?',(id,))
 return redirect('/')
@app.post('/excluir/<int:id>')
def excluir(id):
 query('DELETE FROM manutencoes WHERE id=?',(id,))
 return redirect('/')
if __name__=='__main__': app.run(debug=True)
